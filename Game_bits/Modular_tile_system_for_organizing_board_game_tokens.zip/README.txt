                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2402641
Modular tile system for organizing board game tokens by karakulli is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

The reconstruction of a modular tile system for board game tokens organization as it is seen on [Kickstarter](https://www.kickstarter.com/projects/dogmight/the-component-collector). The system now consists of 7 square and one dice tray with magnets that can be arranged in a plenty of ways allowing to organize any board game component like cards, tokens, golds and much more.


# Print Settings

Printer: Cetus3D
Rafts: Doesn't Matter
Supports: No
Resolution: .3
Infill: 15%

Notes: 
To build one you need to get Neodym magnets of 3x6mm size (4 per tile + 8 for dice tray) like [these](https://www.amazon.de/gp/product/B01MG59CTU) or [these](https://www.amazon.com/dp/B01MXWMF7Q). Print all trays (don't forget to rotate if necessary, print on a flat side) and glue the magnets with super glue in.

**Be careful:** pay attention to which side you glue magnets to. All tiles have a dot on top - make sure they stick together if oriented the same way. 

**Update**
Added new version of Dice Tray - broken in two parts for those who can't print it in one part. The gap between two parts is 0.2mm. Note that I haven't tested it myself so it might not work for you.